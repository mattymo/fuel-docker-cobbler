The Mobile Plugin
=================

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

JavaScript
----------

.. autojs:: ../applications/terminal/plugins/mobile/static/mobile.js
    :members:
