The SSH Plugin
==============

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

JavaScript
----------

ssh.js - The client-side portion of Gate One's SSH plugin.

.. autojs:: ../applications/terminal/plugins/ssh/static/ssh.js
    :members:

Python
------

.. automodule:: ssh
    :members:
    :private-members:
