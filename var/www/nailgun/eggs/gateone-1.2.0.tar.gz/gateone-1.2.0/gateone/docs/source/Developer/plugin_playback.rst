The Playback Plugin
===================

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

JavaScript
----------

playback.js - The client-side portion of Gate One's Playback plugin.

.. autojs:: ../applications/terminal/plugins/playback/static/playback.js
    :members:

Python
------

.. automodule:: playback
    :members:
    :private-members:
