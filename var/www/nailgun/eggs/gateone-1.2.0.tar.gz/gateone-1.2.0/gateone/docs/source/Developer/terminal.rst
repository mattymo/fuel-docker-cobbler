:mod:`terminal.py` - A Pure Python Terminal Emulator
====================================================

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

.. automodule:: terminal
    :members:
    :private-members:
