The Bookmarks Plugin
====================

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

JavaScript
----------

bookmarks.js - The client-side portion of Gate One's Bookmarks plugin.

.. autojs:: ../applications/terminal/plugins/bookmarks/static/bookmarks.js
    :members:

Python
------

.. automodule:: bookmarks
    :members:
    :private-members:
