The Help Plugin
===============

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

JavaScript
----------

.. autojs:: ../applications/terminal/plugins/help/static/help.js
    :members:
