Gate One plugins go in this directory.  They're not the same as applications in that they can modify the behavior of all installed applications simultaneously.
